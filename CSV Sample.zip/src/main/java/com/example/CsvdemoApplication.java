package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class CsvdemoApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(CsvdemoApplication.class, args);
		
		
		 String csvFile = "d://developer.csv";
	        FileWriter writer = new FileWriter(csvFile);

	        List<Developer> developers = Arrays.asList(
	                new Developer("mkyong", "01", 0032),
	                new Developer("zilap", "01", 005),
	                new Developer("ultraman", "01", 005)
	        );

	        //for header
	        CSVUtils.writeLine(writer, Arrays.asList("Name", "Salary", "Age"));

	        for (Developer d : developers) {
              
	            List<String> list = new ArrayList<>();
	            list.add(d.getName());
	            list.add(String.valueOf(d.getSalary()));
	            list.add(String.valueOf(d.getAge()));

	            CSVUtils.writeLine(writer, list);

				//try custom separator and quote.
				//CSVUtils.writeLine(writer, list, '|', '\"');
	        }

	        writer.flush();
	        writer.close();

	    }
		
		
	}

