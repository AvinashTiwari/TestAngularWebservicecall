import { Component } from '@angular/core';
 import {Http, Response} from '@angular/http';
 import 'rxjs/Rx';

@Component({
  selector: 'my-app',
  template: `<h1>Hello {{name}}</h1>`,
})
export class AppComponent  { 

  constructor(http: Http)
  {
    console.log("Going to call get");
http.get('http://localhost:8080/greeting?name=Avinash').toPromise()
            .then(res => {
                let a = res;
                              console.log(" toke accesed " + a.headers.get('Avinash_preHandle'))
            }).catch(err => console.log(err));;




  }
  
  name = 'Angular Avinash'; 

}
